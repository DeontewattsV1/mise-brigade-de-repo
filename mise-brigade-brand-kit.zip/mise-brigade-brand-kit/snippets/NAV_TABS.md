<!-- Mise Brigade visual nav -->

<table>
  <tr>
    <td width="20%"><img src="./brand/assets/svg/tabs/tab-issues-review.svg" alt="Issues and Review" /></td>
    <td width="20%"><img src="./brand/assets/svg/tabs/tab-merge-pr.svg" alt="Merge and PR" /></td>
    <td width="20%"><img src="./brand/assets/svg/tabs/tab-branch-corrections.svg" alt="Branch Corrections" /></td>
    <td width="20%"><img src="./brand/assets/svg/tabs/tab-comments-commits.svg" alt="Comments and Commits" /></td>
    <td width="20%"><img src="./brand/assets/svg/tabs/tab-repo-clean.svg" alt="Repo Clean" /></td>
  </tr>
</table>
