# Mise Brigade de Repo

<p align="center">
  <img src="./brand/assets/svg/banners/readme-hero-banner.svg" alt="Mise Brigade de Repo banner" width="100%" />
</p>

<p align="center">
  <img src="./brand/assets/svg/badges/badge-mise-steward.svg" alt="Mise Steward badge" height="80" />
  <img src="./brand/assets/svg/badges/badge-safe-automation.svg" alt="Safe Automation badge" height="80" />
  <img src="./brand/assets/svg/badges/badge-github-token.svg" alt="GITHUB_TOKEN badge" height="80" />
</p>

## Repository Stations

<img src="./brand/assets/svg/tabs/tab-issues-review.svg" alt="Issues and Review" width="100%" />
<img src="./brand/assets/svg/tabs/tab-merge-pr.svg" alt="Merge and PR" width="100%" />
<img src="./brand/assets/svg/tabs/tab-branch-corrections.svg" alt="Branch Corrections" width="100%" />
<img src="./brand/assets/svg/tabs/tab-comments-commits.svg" alt="Comments and Commits" width="100%" />
<img src="./brand/assets/svg/tabs/tab-repo-clean.svg" alt="Repo Clean" width="100%" />

## Brand Line

**Mise Brigade de Repo** is the code-chef layer of the Mise en Place Hub: every branch, issue, review, comment, and cleanup pass gets routed like a kitchen station with clear ownership, clean prep, and safe service.
