<!-- Mise Brigade badges -->

<p align="center">
  <img src="./brand/assets/svg/badges/badge-mise-steward.svg" alt="Mise Steward" height="72" />
  <img src="./brand/assets/svg/badges/badge-safe-automation.svg" alt="Safe Automation" height="72" />
  <img src="./brand/assets/svg/badges/badge-github-token.svg" alt="GITHUB_TOKEN" height="72" />
  <img src="./brand/assets/svg/badges/badge-no-pat-recursion.svg" alt="No PAT recursion" height="72" />
  <img src="./brand/assets/svg/badges/badge-trusted-routes.svg" alt="Trusted Routes" height="72" />
</p>
