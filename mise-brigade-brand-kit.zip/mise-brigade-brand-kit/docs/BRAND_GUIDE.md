# Mise Brigade de Repo Brand Guide

## Positioning

**Mise Brigade de Repo** is a chef-code repository identity for the Mise en Place Hub. It frames repository maintenance as a kitchen brigade: every workflow mode has a station, every branch has a plate, and every write action has a safety gate.

## Core line

Chef-coded stewardship for clean repositories.

## Expanded line

Everything in its place: branch flow, steward checks, safe automation, readable repo rituals.

## Naming

Use **Mise Brigade de Repo** as the primary name.

Use **Mise Repo Steward** for the workflow/action layer.

Use **Mise en Place Hub** for the larger ecosystem.

## Visual system

- Dark kitchen/terminal base
- Flame accents for urgency and action
- Green garnish accents for safety and passing gates
- Blue flame accents for review intelligence and route clarity
- Mono terminal type for commands
- Rounded cards, labels, and station tabs

## Workflow station mapping

| Station | Visual file | Brand role |
|---|---|---|
| Issues & Review | `assets/svg/tabs/tab-issues-review.svg` | Triage the pantry before cooking |
| Merge & PR | `assets/svg/tabs/tab-merge-pr.svg` | Plate branches only after gates pass |
| Branch Corrections | `assets/svg/tabs/tab-branch-corrections.svg` | Slice drift and suggest the next clean branch |
| Comments & Commits | `assets/svg/tabs/tab-comments-commits.svg` | Turn kitchen notes into digestible context |
| Repo Clean | `assets/svg/tabs/tab-repo-clean.svg` | Reset the station and keep the line moving |

## Safety language to keep

- GITHUB_TOKEN
- Scoped job-level permissions
- No `pull_request_target`
- No PAT recursion
- `[skip ci]` generated commits
- Trusted collaborator comment routing
- Write actions only when `apply` is explicitly requested

## README hero block

Use `snippets/README_DECORATIONS.md` as the starting point.
