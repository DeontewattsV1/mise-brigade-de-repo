# Mise Brigade de Repo Brand Kit

Chef-inspired repository branding for the Mise en Place Hub.

Generated assets are static SVGs and repository-safe snippets. No GitHub push or repo write was performed.

## Includes

- Primary logo mark and horizontal lockup
- README hero banner
- Terminal hero graphic
- Social preview card
- Five workflow station tabs aligned to the Mise Repo Steward modes
- Safety badges for GitHub-safe automation language
- Section headers, divider, CSS tokens, JSON tokens
- GitHub label suggestions
- Copy-to-repo instructions

## Fast use

```bash
unzip mise-brigade-brand-kit.zip
cd mise-brigade-brand-kit
./scripts/install-brand-kit.sh /path/to/mise-brigade-de-repo
```

Then copy from `snippets/README_DECORATIONS.md` into your repository README.

## Main files

- `COPY_TO_REPO.md`
- `assets/svg/badges/badge-github-token.svg`
- `assets/svg/badges/badge-mise-steward.svg`
- `assets/svg/badges/badge-no-pat-recursion.svg`
- `assets/svg/badges/badge-safe-automation.svg`
- `assets/svg/badges/badge-trusted-routes.svg`
- `assets/svg/banners/readme-hero-banner.svg`
- `assets/svg/banners/social-card.svg`
- `assets/svg/banners/terminal-hero.svg`
- `assets/svg/decor/mise-divider.svg`
- `assets/svg/decor/section-commands.svg`
- `assets/svg/decor/section-installation.svg`
- `assets/svg/decor/section-overview.svg`
- `assets/svg/decor/section-roadmap.svg`
- `assets/svg/decor/section-safety.svg`
- `assets/svg/logos/favicon.svg`
- `assets/svg/logos/mise-brigade-horizontal.svg`
- `assets/svg/logos/mise-brigade-logo-mark.svg`
- `assets/svg/tabs/tab-branch-corrections.svg`
- `assets/svg/tabs/tab-comments-commits.svg`
- `assets/svg/tabs/tab-issues-review.svg`
- `assets/svg/tabs/tab-merge-pr.svg`
- `assets/svg/tabs/tab-repo-clean.svg`
- `brand.css`
- `brand.tokens.json`
- `docs/BRAND_GUIDE.md`
- `github/labels.json`
- `index.html`
- `scripts/install-brand-kit.sh`
- `scripts/validate-brand-kit.py`
- `snippets/BADGES.md`
- `snippets/NAV_TABS.md`
- `snippets/README_DECORATIONS.md`
